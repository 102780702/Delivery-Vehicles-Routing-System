public enum SelectionType {
    TOURNAMENT,
    ROULETTE
}
