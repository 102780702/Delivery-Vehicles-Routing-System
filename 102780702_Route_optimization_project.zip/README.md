# Delivery-Vehicles-Routing-System
102780702 - Jun Sieng KONG 

102782876 - Tara Jane BHASKER 

102774912 - Clement Cheng CHANG

102772505 - Julian Chet Shiang JEE 

**Communication Diagram**

![communication_diagram](https://github.com/102780702/Delivery-Vehicles-Routing-System/assets/145240138/9de48145-1bf6-4676-b196-0595fed6bac3)

**Communication Diagram - Sniffer Version**

![image](https://github.com/102780702/Delivery-Vehicles-Routing-System/assets/145240138/b43e4ea3-ce93-457f-ada6-6f72bbd2c053)

